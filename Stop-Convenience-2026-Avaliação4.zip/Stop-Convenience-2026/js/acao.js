// carrossel
var slider = document.querySelectorAll('.slider'); //seleciona todas as imagens que tem a classe .slider
var btnPrev = document.getElementById("btnVoltar");
var btnNext = document.getElementById("btnAvancar");

var timer;

var currentSlide = 0; //indice das imagens

window.onload = inicio;

function inicio(){
    btnNext.onclick = nextSlider
    btnPrev.onclick = prevtSlider
    showSlider();
    slideAutomatico();
}

function slideAutomatico(){
    timer = setInterval(nextSlider, 5000)
}

function hideSlider(){ 
    slider.forEach(item => item.classList.remove('on')) //remove a classe .on do array de imagens (a imagem que tiver a classe .on vai sumir)
}

function showSlider(){
    slider[currentSlide].classList.add('on') //mostrar a imagem correspondente ao indice, dessa forma, se currentSlide = 1, vai mostrar a imagem correspondente
}

function nextSlider(){
    hideSlider()
    if(currentSlide == slider.length -1){ /*se o slide atual for igual ao último slide, então volta para o primeiro slide*/
        currentSlide = 0 
    }else{    //se não, incrementa o indice 
        currentSlide++
    }
    showSlider();
    clearInterval(timer); //reinicia o timer
    slideAutomatico();
}

function prevtSlider(){
    hideSlider();
    if(currentSlide == 0){ // Verifica se o slide atual é o primeiro slide (índice 0)
        currentSlide = slider.length -1 // Se estiver no primeiro slide, volta para o último slide
    }else{ //se não, subtrai o indice
        currentSlide--
    }
    showSlider();
    clearInterval(timer);
    slideAutomatico();
}

// ---  DA BARRA DE PESQUISA ---
document.addEventListener('DOMContentLoaded', function () {
    const inputBuscar = document.getElementById('buscar'); 
    const produtos = document.querySelectorAll('.produto'); //Seleciona todos os elementos que possuem a classe "produto"
    //verifica se a barra de pesquisa estiver disponivel
    if (inputBuscar) {
        inputBuscar.addEventListener('input', function () {
            // Pega o texto digitado pelo usuário no campo de pesquisa.
            // toLowerCase() transforma todas as letras em minúsculas.
            // trim() remove os espaços em branco do início e do final.
            const termo = inputBuscar.value.toLowerCase().trim();

            produtos.forEach(function (produto) { // Percorre todos os produtos encontrados na página
                // Verifica se o elemento com a classe "nome" existe.
                const nomeElemento = produto.querySelector('.nome');
                // Se existir, pega o textContent e transforma
                // todas as letras em minúsculas.
                // Se não existir, atribui uma string vazia ('')
                const nomeTexto = nomeElemento ? nomeElemento.textContent.toLowerCase() : '';

                // 'block' Mostra o produto se o nome incluir o que foi digitado, caso contrário, 'none' esconde
                if (nomeTexto.includes(termo)) {
                    produto.style.display = 'block';
                } else {
                    produto.style.display = 'none';
                }
            });
        });
    }
});